import sys
import time
import math
import numpy as np
from scipy.spatial.transform import Rotation as R
import pygame
from pygame.locals import *

CANVAS_WIDTH = 1920
CANVAS_HEIGHT = 1080

pygame.init()
screen = pygame.display.set_mode((CANVAS_WIDTH,CANVAS_HEIGHT))
screen.set_alpha(None)
clock = pygame.time.Clock()

FOV = 1.5
camera_p = np.array([10.0,4.0,12.0])
camera_r = 0.0

car_p = np.array([0.0,1.0,12.0])
car_r = -1.5707
car_v = np.array([0.0,0.0,0.0])



#Load road mesh
roadverts = np.loadtxt(
    "roadmesh/roadverts.txt",  
    dtype=float     
)
roadtris = np.loadtxt(
    "roadmesh/roadtris.txt",  
    dtype=int
)

#Load car mesh
carverts = np.loadtxt(
    "carmesh/carverts.txt",  
    dtype=float     
)
cartris = np.loadtxt(
    "carmesh/cartris.txt",  
    dtype=int
)

#Load environment mesh
envverts = np.loadtxt(
    "envmesh/envverts.txt",  
    dtype=float     
)
envtris = np.loadtxt(
    "envmesh/envtris.txt",  
    dtype=int
)

carmesh = []
roadmesh = []
envmesh = []

for tri in cartris:
    carmesh.append([
            [
                carverts[tri[0]][0],
                carverts[tri[0]][1],
                carverts[tri[0]][2]
            ],
            [
                carverts[tri[1]][0],
                carverts[tri[1]][1],
                carverts[tri[1]][2]
            ],
            [
                carverts[tri[2]][0],
                carverts[tri[2]][1],
                carverts[tri[2]][2]
            ]
            #tri[3]
        ])
    
for tri in roadtris:
    roadmesh.append([
            [
                roadverts[tri[0]][0],
                roadverts[tri[0]][1],
                roadverts[tri[0]][2]
            ],
            [
                roadverts[tri[1]][0],
                roadverts[tri[1]][1],
                roadverts[tri[1]][2]
            ],
            [
                roadverts[tri[2]][0],
                roadverts[tri[2]][1],
                roadverts[tri[2]][2]
            ]
            #tri[3]
        ])

for tri in envtris:
    envmesh.append([
            [
                envverts[tri[0]][0],
                envverts[tri[0]][1],
                envverts[tri[0]][2]
            ],
            [
                envverts[tri[1]][0],
                envverts[tri[1]][1],
                envverts[tri[1]][2]
            ],
            [
                envverts[tri[2]][0],
                envverts[tri[2]][1],
                envverts[tri[2]][2]
            ]
            #tri[3]
        ])














def print_scene(camera_pos, camera_rot):

    #Draws background
    temptris = []
    
    screen.fill([130,170,250])

    pygame.draw.polygon(screen, [10,160,10], [(CANVAS_WIDTH, CANVAS_HEIGHT),(0,CANVAS_HEIGHT),
                                          (0,CANVAS_HEIGHT/2-368),(CANVAS_WIDTH,CANVAS_HEIGHT/2-368)])

    #Setup
    x = float(CANVAS_WIDTH)
    y = float(CANVAS_HEIGHT)

    tanFOVx = math.tan(FOV/2)*2
    tanFOVy = math.tan(FOV*(float(CANVAS_HEIGHT)/float(CANVAS_WIDTH))/2)*2

    #Transforms meshes
    temptris += roadmesh
    temptris += list(map(lambda tri: [tri[0]+car_p, tri[1]+car_p, tri[2]+car_p], R.from_euler('y', car_r).apply(carmesh)))
    temptris += envmesh

    temptris = list(map(lambda tri: [tri[0]-camera_pos, tri[1]-camera_pos, tri[2]-camera_pos], temptris))
    temptris = (R.from_euler('y', camera_rot).apply(temptris)).tolist()
    temptris = (R.from_euler('x', -0.3).apply(temptris)).tolist()

    #Applies materials
    for temptri,tri in zip(temptris,(list(roadtris)+list(cartris)+list(envtris))):
        temptri = temptri.append(tri[3])

    #Sorts polygons (Painter's method)
    temptris[len(roadtris):len(temptris)] = sorted(temptris[len(roadtris):len(temptris)],key=lambda tri: tri[0][2] +tri[1][2] +tri[2][2], reverse=True)

    #Draws meshes
    for tri in temptris:

        posx1 = (tri[0][0]/abs(tri[0][2]*tanFOVx))*x + x/2
        posy1 = (tri[0][1]/abs(tri[0][2]*tanFOVy))*-y + y/2
        posx2 = (tri[1][0]/abs(tri[1][2]*tanFOVx))*x + x/2
        posy2 = (tri[1][1]/abs(tri[1][2]*tanFOVy))*-y + y/2
        posx3 = (tri[2][0]/abs(tri[2][2]*tanFOVx))*x + x/2
        posy3 = (tri[2][1]/abs(tri[2][2]*tanFOVy))*-y + y/2

        rendfac = 400

        rendercondition = (
        (tri[0][2]>0.1 and tri[1][2]>0.1 and tri[2][2]>0.1)
        and
        (
            (posx1>0-rendfac and posx1<x+rendfac and posy1>0-rendfac and posy1<y+rendfac)
            or
            (posx2>0-rendfac and posx2<x+rendfac and posy2>0-rendfac and posy2<y+rendfac)
            or
            (posx3>0-rendfac and posx3<x+rendfac and posy3>0-rendfac and posy3<y+rendfac)
        )
        )
        if rendercondition:
            if tri[3] == 0:
                pygame.draw.polygon((screen), (150,160,170), [(posx1,posy1),(posx2,posy2),(posx3,posy3)])
            if tri[3] == 1:
                pygame.draw.polygon((screen), (200,30,40), [(posx1,posy1),(posx2,posy2),(posx3,posy3)])
            if tri[3] == 2:
                pygame.draw.polygon((screen), (10,10,40), [(posx1,posy1),(posx2,posy2),(posx3,posy3)])
            if tri[3] == 3:
                pygame.draw.polygon((screen), (230,230,230), [(posx1,posy1),(posx2,posy2),(posx3,posy3)])














clock = pygame.time.Clock()

running = True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    keys = pygame.key.get_pressed()
    
    dist_xz = math.sqrt((car_p[0]-camera_p[0])**2 +(car_p[2]-camera_p[2])**2)
    camera_p += (dist_xz -8.0) *(car_p -camera_p +[0,3,0]) *0.03
    camera_r = math.atan2(car_p[2] -camera_p[2], car_p[0] -camera_p[0]) -1.5707

    car_n = np.array([math.sin(car_r), 0, math.cos(car_r)])
    car_v += (car_v.dot(car_n)*car_n -car_v)
    if keys[pygame.K_DOWN]:
        car_v += car_n * (-2-np.linalg.norm(car_v))*1 *(1/60)
    elif keys[pygame.K_UP]:
        car_v += car_n * (20-np.linalg.norm(car_v))*0.5 *(1/60)
    else:
        car_v += -car_v* 0.2 *(1/60)
    if keys[pygame.K_RIGHT]:
        car_r += np.linalg.norm(car_v)*0.002
    if keys[pygame.K_LEFT]:
        car_r += np.linalg.norm(car_v)*-0.002
    car_p += car_v *(1/60)
        
    print_scene(camera_p,camera_r)
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()
